import joblib
import pandas as pd
from flask import Flask, request, render_template
from geopy.geocoders import Nominatim

endpoint = 'https://maps.googleapis.com/maps/api/geocode/json?address='
key = 'AIzaSyDM8KzL_OAF9lfK7ZAFCo3I74k63jG24'

app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    global my_prediction
    rfc = joblib.load('model/rf_model')
    print('model loaded')

    if request.method == 'POST':
        address = request.form['Location']
        geolocator = Nominatim()
        location = geolocator.geocode(address)
        print(location.address)
        lat = [location.latitude]
        log = [location.longitude]
        latlng = pd.DataFrame({'latitude': lat, 'longitude': log})
        print(latlng)

        dt = request.form['timestamp']
        latlng['timestamp'] = dt
        data = latlng
        my_prediction = rfc.predict(data)

    return render_template('result.html', prediction=my_prediction)


if __name__ == '__main__':
    app.run(debug=True)
